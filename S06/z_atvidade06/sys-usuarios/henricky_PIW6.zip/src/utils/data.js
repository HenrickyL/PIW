let infoPosts = [
    {
        id:1,
        nomeUsuario:"Henricky",
        texto:"Será que ficou bonito? ou está demais? kkkk",
        qtdLikes:5,
        active:true
    },
    {
        id:2,
        nomeUsuario:"João",
        texto:"Menino, tá quente demais hoje",
        qtdLikes:1,
        active:false

    },
    {
        id:3,
        nomeUsuario:"Tiago",
        texto:"Num aguento mais essa quintura",
        qtdLikes:3,
        active:false

    },
    {
        id:4,
        nomeUsuario:"Pedrosa",
        texto:"Dá refresh na página!!! Olha o que acontece.",
        qtdLikes:3,
        active:false

    },
    
    {
        id:5,
        nomeUsuario:"Mateus",
        texto:"Terminou o tabalho? Bora jogar",
        qtdLikes:8,
        active:true

    },
    {
        id:6,
        nomeUsuario:"Victor",
        texto:"Terminou ai velho?",
        qtdLikes:4,
        active:false

    },
    
]
let infoComments = [
    {
        id:1,
        idPost:1,
        nomeUsuario:"Marcio",
        texto:"Ficou daora",
        qtdLikes:3,
        active:true

    },
    {
        id:2,
        idPost:1,
        nomeUsuario:"Henricky",
        texto:"vlw mano (^^)",
        qtdLikes:2,
        active:false
    },
    {
        id:3,
        idPost:2,
        nomeUsuario:"Pedrosa",
        texto:"D++, vou derreter Ç_Ç",
        qtdLikes:2,
        active:false

    },
    
    {
        id:6,
        idPost:6,
        nomeUsuario:"Henricky",
        texto:"Já sim, foi daora demais....",
        qtdLikes:4,
        active:false

    },
    
]


export {
    infoPosts,
    infoComments
}