export const fruit=[
    'abacaxi.svg',
    'banana.svg',
    'maca.svg',
    'melancia.svg',
    'morango.svg',
    'pera.svg',
    'uva.svg',
    'laranja.svg',
]