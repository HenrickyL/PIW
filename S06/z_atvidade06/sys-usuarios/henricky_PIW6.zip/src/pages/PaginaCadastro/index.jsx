import Cabecalho from '../../components/Cabecalho'

import {FormCadastro} from '../../components/FormCadastro'





export function PaginaCadastro(){
    return(
        <div className='home '>
            <Cabecalho />
            <FormCadastro />
            
        </div>
    )
}