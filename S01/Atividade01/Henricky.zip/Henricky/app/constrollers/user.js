let users = []

// {
//     “id”: “1”,
//     “nome”: “Victor”,
//     “email”: “victor.aefarias@gmail.com”,
//     “senha”: “123”
// }
module.exports.userList = (req,res)=>{
    if('nome' in req.query){
        let nome = req.query.nome
        let user_res = users.filter(u=>u.nome.toLocaleLowerCase()==nome)
        res.json(user_res)
    }else{
        res.json(users)
    }
}
module.exports.getUser = (req,res)=>{
    let id = req.params.id
    let user = users.find(u=>u.id ==id)
    if(user){
        res.send(user)
    }else{
        res.status(404).send("Usuário não encontrado!")
    }
}
module.exports.addUser = (req,res)=>{
    console.log('get addUser')
    let user = req.body
    if(user!={}){
        users.push(user)
        res.status(201).json(user)
    }else{
        res.status(400).send('Usuário inválido')

    }
}
module.exports.deleteUser = (req,res)=>{
    let id = req.params.id
    let user = users.find(u=>u.id==id)
    if(user){
        users = users.filter(u=>u.id != id)
        res.status(204).json(user)
    }else{
        res.status(404).send('Usuário não encontrado!')
        
    }
}