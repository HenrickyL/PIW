import Cabecalho from '../../components/Cabecalho'

import {FormLogin} from '../../components/FormLogin'





export function PaginaLogin(){
    return(
        <div className='home '>
            <Cabecalho />
            <FormLogin />
            
        </div>
    )
}