const bodyParser = require('body-parser')
const express = require('express')
const userRouter = require('../app/routers/user')
const postRouter = require('../app/routers/post')


module.exports = ()=>{
    const app = express()
    app.use(express.static('./public'))
    app.set('port',5001)
    app.use(bodyParser.json())
    app.use(bodyParser.urlencoded({extended:false}))
    //rotas
    userRouter(app)
    postRouter(app)

    app.all('/*',(req,res)=>{
        res.status(404).send("Não encontrado")
    })
    return app
}