let userController = require('../constrollers/user')

module.exports = (app)=>{
    app.post('/api/usuarios',userController.addUser)
    app.get('/api/usuarios',userController.userList)
    app.get('/api/usuarios/:id',userController.getUser)
    app.delete('/api/usuarios/:id',userController.deleteUser)
}