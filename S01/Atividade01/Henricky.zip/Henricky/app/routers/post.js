let postController = require('../constrollers/post')

module.exports = (app)=>{
    app.post('/api/posts',postController.addPost)
    app.get('/api/posts',postController.postList)
    app.get('/api/posts/:id',postController.getPost)
    app.delete('/api/posts/:id',postController.deletePost)
}