let posts = []
// {
//     “id”: “1”,
//     “texto”: “Oi, tudo bem?”,
//     “likes”: “6”
// }
module.exports.postList = (req,res)=>{
    if('nome' in req.query){
        let nome = req.query.nome
        let post_res = posts.filter(p=>p.nome.toLocaleLowerCase()==nome)
        res.json(post_res)
    }else{
        res.json(posts)
    }
}
module.exports.getPost = (req,res)=>{
    let id = req.params.id
    let post = posts.find(p=>p.id ==id)
    if(post){
        res.send(post)
    }else{
        res.status(404).send("Post não encontrado!")
    }
}
module.exports.addPost = (req,res)=>{
    let post = req.body
    if(post!={}){
        posts.push(post)
        res.status(201).json(post)
    }else{
        res.status(400).send('Post inválido')

    }
}
module.exports.deletePost = (req,res)=>{
    let id = req.params.id
    let post = posts.find(p=>p.id==id)
    if(post){
        posts = posts.filter(p=>p.id != id)
        res.status(204).json(post)
    }else{
        res.status(404).send('Post não encontrado!')
        
    }
}